function changeColor() {
    var w = window.outerWidth;
    var h = window.outerHeight;
    if(w>1280 || h>1024) {
        document.getElementById("page-container").style.backgroundColor = "#cccccc";
    }
    else{
        document.getElementById("page-container").style.backgroundColor = "red";
    }
}
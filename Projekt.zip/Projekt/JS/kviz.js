/*https://simplestepscode.com/javascript-quiz-tutorial/*/
var myQuestions = [
    {
        question: "1. Što zapravo znači Staljin?",
        answers: {
            a: 'Čelični čovjek',
            b: 'Jaki čovjek',
            c: 'Veliki čovjek'
        },
        correctAnswer: 'a'
    },
    {
        question: "2. Kako se zove knjiga koju je Hitler napisao u zatvoru?",
        answers: {
            a: ' Mein Kampf ',
            b: ' Mein Gefängnis ',
            c: ' Meine Liebe '
        },
        correctAnswer: 'a'
    },
    {
        question: "3. Kada je umro Staljin?",
        answers: {
            a: '5. veljače 1953',
            b: '30. travnja 1945.',
            c: '12. travnja 1945.',
            d: '24. siječnja 1965.'
        },
        correctAnswer: 'a'
    },
    {
        question: "4. Gdje je rođen Roosevelt?",
        answers: {
            a: 'Washington',
            b: 'New York',
            c: 'Chicago'
        },
        correctAnswer: 'b'
    },
    {
        question: "5. Tko je zatražio \"Novi dogovor\"?",
        answers: {
            a: 'Staljin',
            b: 'Churchill',
            c: 'Roosevelt',
            d: 'Hitler'
        },
        correctAnswer: 'c'
    },
    {
        question: "6. Tko nije isprva mislio da je Hitler prijetnja?",
        answers: {
            a: 'Roosevelt',
            b: 'Churchill',
            c: 'Staljin',
        },
        correctAnswer: 'b'
    },
    {
        question: "7. Tko je bio Staljinov prethodnik?",
        answers: {
            a: 'Vladimir Lenjin',
            b: 'Georgij Malenkov',
            c: 'Nikita Hruščov',
            d: 'Nitko od navedenih'
        },
        correctAnswer: 'a'
    },
    {
        question: "8. Tko je doživio srčani udar tijekom posjete Bijeloj kući?",
        answers: {
            a: 'Churchill',
            b: 'Roosevelt',
            c: 'Staljin'
        },
        correctAnswer: 'a'
    },
    {
        question: "9. Tko je umro od velikog cerebralnog krvarenja?",
        answers: {
            a: 'Hitler',
            b: 'Staljin',
            c: 'Roosevelt',
            d: 'Churchill'
        },
        correctAnswer: 'c'
    },
    {
        question: "10. Tko je od navedenih bio uhićen?",
        answers: {
            a: 'Staljin',
            b: 'Churchill',
            c: 'Roosevelt',
            d: 'Hitler',
            e: 'Nitko od navedenih'
        },
        correctAnswer: 'd'
    },

];

var quizContainer = document.getElementById('quiz');
var submitButton = document.getElementById('submit');

generateQuiz(myQuestions, quizContainer, submitButton);

function generateQuiz(questions, quizContainer, submitButton){

    function showQuestions(questions, quizContainer){
        var output = [];
        var answers;

        for(var i=0; i<questions.length; i++){

            answers = [];

            for(letter in questions[i].answers){

                answers.push(
                    '<label>'
                    + '<input type="radio" name="question'+i+'" value="'+letter+'">'
                    + '\n'
                    + letter + ': '
                    + questions[i].answers[letter]
                    +'<br/>'
                    +'</label>'
                );
            }

            output.push(
                '<div class="question">' + questions[i].question + '</div>' + '<br>'
                + '<div class="answers">' + answers.join('') + '</div>'
            );
        }

        quizContainer.innerHTML = output.join('');
    }


    function showResults(questions, quizContainer,){

        var answerContainers = quizContainer.querySelectorAll('.answers');

        var userAnswer = '';
        var numCorrect = 0;

        for(var i=0; i<questions.length; i++){

            userAnswer = (answerContainers[i].querySelector('input[name=question'+i+']:checked')||{}).value;

            if(userAnswer===questions[i].correctAnswer){
                numCorrect++;
                answerContainers[i].style.color = '#00a830';
            }

            else{
                answerContainers[i].style.color = 'red';
            }
        }
        if (numCorrect>0 && numCorrect<=4){
            alert(((numCorrect/10)*100) + '%. Dobio si ocjenu nedovoljan 1.')
        }
        else if (numCorrect>4 && numCorrect<=6){
            alert(((numCorrect/10)*100) + '%. Dobio si ocjenu dovoljan 2.')
        }
        else if (numCorrect>6 && numCorrect<8) {
            alert(((numCorrect / 10) * 100) + '%. Dobio si ocjenu dobar 3.')
        }
        else if (numCorrect>=8 && numCorrect<10) {
            alert(((numCorrect / 10) * 100) + '%. Dobio si ocjenu vrlo dobar 4.')
        }
        else if (numCorrect === 10) {
            alert(((numCorrect / 10) * 100) + '%. Dobio si ocjenu odličan 5. Bravo!')
        }
        else{
            alert('Ništa nisi znao. Sram te bilo. Dobio si 1.')
        }
    }

    showQuestions(questions, quizContainer);

    submitButton.onclick = function(){
        showResults(questions, quizContainer);
    }

}
